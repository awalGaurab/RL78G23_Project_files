/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability 
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : Config_UART2_user.c
* Version      : 1.1.0
* Device(s)    : R7F100GLGxFB
* Description  : This file implements device driver for Config_UART2.
***********************************************************************************************************************/
/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "r_cg_userdefine.h"
#include "Config_UART2.h"
/* Start user code for include. Do not edit comment generated here */
#include <stdarg.h>
#include "r_smc_entry.h"
#include "hd44780.h"
//#include <stdio.h> 
//#include <ctype.h>
//#include <string.h>

/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
#pragma interrupt r_Config_UART2_interrupt_send(vect=INTST2)
#pragma interrupt r_Config_UART2_interrupt_receive(vect=INTSR2)
#pragma interrupt r_Config_UART2_interrupt_error(vect=INTSRE2)
/* Start user code for pragma. Do not edit comment generated here */
void r_uart2_int_recv(uint16_t rx_data);
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
extern volatile uint8_t * gp_uart2_tx_address;    /* uart2 transmit buffer address */
extern volatile uint16_t g_uart2_tx_count;        /* uart2 transmit data number */
extern volatile uint8_t * gp_uart2_rx_address;    /* uart2 receive buffer address */
extern volatile uint16_t g_uart2_rx_count;        /* uart2 receive data number */
extern volatile uint16_t g_uart2_rx_length;       /* uart2 receive data length */
/* Start user code for global. Do not edit comment generated here */
struct UART2_fifo uart2_rxfifo;  // 120�޲� ��M�ޯ̧ 
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_UART2_Create_UserInit
* Description  : This function adds user code after initializing UART2.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_UART2_Create_UserInit(void)
{
    /* Start user code for user init. Do not edit comment generated here */
    /* End user code. Do not edit comment generated here */
}

/***********************************************************************************************************************
* Function Name: r_Config_UART2_callback_sendend
* Description  : This function is a callback function when UART2 finishes transmission.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static void r_Config_UART2_callback_sendend(void)
{
    /* Start user code for r_Config_UART2_callback_sendend. Do not edit comment generated here */
    /* End user code. Do not edit comment generated here */
}

/***********************************************************************************************************************
* Function Name: r_Config_UART2_callback_receiveend
* Description  : This function is a callback function when UART2 finishes reception.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static void r_Config_UART2_callback_receiveend(void)
{
    /* Start user code for r_Config_UART2_callback_receiveend. Do not edit comment generated here */
    /* End user code. Do not edit comment generated here */
}

/***********************************************************************************************************************
* Function Name: r_Config_UART2_callback_error
* Description  : This function is a callback function when UART2 reception error occurs.
* Arguments    : err_type -
*                    error type info
* Return Value : None
***********************************************************************************************************************/
static void r_Config_UART2_callback_error(uint8_t err_type)
{
    /* Start user code for r_Config_UART2_callback_error. Do not edit comment generated here */
    /* End user code. Do not edit comment generated here */
}

/***********************************************************************************************************************
* Function Name: r_Config_UART2_callback_softwareoverrun
* Description  : This function is a callback when UART2 receives an overflow data.
* Arguments    : rx_data -
*                    receive data
* Return Value : None
***********************************************************************************************************************/
static void r_Config_UART2_callback_softwareoverrun(uint16_t rx_data)
{
    /* Start user code for r_Config_UART2_callback_softwareoverrun. Do not edit comment generated here */
    r_uart2_int_recv(rx_data);
    /* End user code. Do not edit comment generated here */
}

/***********************************************************************************************************************
* Function Name: r_Config_UART2_interrupt_send
* Description  : This function is UART2 send interrupt service routine.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static void __near r_Config_UART2_interrupt_send(void)
{
    if (g_uart2_tx_count > 0U)
    {
        TXD2 = *gp_uart2_tx_address;
        gp_uart2_tx_address++;
        g_uart2_tx_count--;
    }
    else
    {
        r_Config_UART2_callback_sendend();
    }
}

/***********************************************************************************************************************
* Function Name: r_Config_UART2_interrupt_receive
* Description  : This function is UART2 receive interrupt service routine.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static void __near r_Config_UART2_interrupt_receive(void)
{
    uint8_t rx_data;

    rx_data = RXD2;

    if (g_uart2_rx_length > g_uart2_rx_count)
    {
        *gp_uart2_rx_address = rx_data;
        gp_uart2_rx_address++;
        g_uart2_rx_count++;

        if (g_uart2_rx_length == g_uart2_rx_count)
        {
            r_Config_UART2_callback_receiveend();
        }
    }
    else
    {
        r_Config_UART2_callback_softwareoverrun(rx_data);
    }
}

/***********************************************************************************************************************
* Function Name: r_Config_UART2_interrupt_error
* Description  : This function is UART2 error interrupt service routine.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static void __near r_Config_UART2_interrupt_error(void)
{
    uint8_t err_type;

    *gp_uart2_rx_address = RXD2;
    err_type = (uint8_t)(SSR11 & 0x0007U);
    SIR11 = (uint16_t)err_type;
    r_Config_UART2_callback_error(err_type);
}

/* Start user code for adding. Do not edit comment generated here */
//*****************************************************
// UART2���䕔(RS-485:ADM3072E����ɂ��)
//*****************************************************

//*****************************************************
//��UART2��M�ݸ��ޯ̧�֊i�[
//-----------------------------------------------------
// ��M�����ݏ��� ��M�ݸ��ޯ̧�֊i�[
//-----------------------------------------------------
//*****************************************************
void r_uart2_int_recv(uint16_t rx_data)
{
    uint8_t n, i;

    if(((uint8_t)rx_data > 0) && ((uint8_t)rx_data < 0x80)) {
        n = uart2_rxfifo.count;
        if(n < sizeof(uart2_rxfifo.buff)) {
            uart2_rxfifo.count = ++n;
            i = uart2_rxfifo.idx_w;
            uart2_rxfifo.buff[i++] = (uint8_t)rx_data;
            if(i >= sizeof(uart2_rxfifo.buff))
                i = 0;
            uart2_rxfifo.idx_w = i;
        }
    }
}
//*****************************************************
//��UART2��M�ޯ̧����1������o(RS-485)
//-----------------------------------------------------
// �ߒl d:�擾�ް�
//-----------------------------------------------------
//*****************************************************
uint8_t uart2_getc(void)
{
    uint8_t d, i;

    i = uart2_rxfifo.idx_r;
    while(uart2_rxfifo.count == 0);
    d = uart2_rxfifo.buff[i++];
    DI();   //���荞�݋֎~
    uart2_rxfifo.count--;
    EI();   //���荞�݋���
    if(i >= sizeof(uart2_rxfifo.buff))
        i = 0;
    uart2_rxfifo.idx_r = i;

    return d;
}
//*****************************************************
//��UART2�ɂ��1�o�C�g�o��(RS-485)
//-----------------------------------------------------
// ���� data:�o�͒l
//      con:RS-485����M�ؑ֐�����s����(0:����,1:�L��)
//-----------------------------------------------------
// �ߒl 0
//-----------------------------------------------------
//*****************************************************
uint8_t uart2_putc(uint8_t data, uint8_t con)
{
    if(con == 1) {
        DE_485 = 1;     //ADM7032E��ײ��Enable(���MӰ�ރw�؂�ւ�)
        RE_485 = 1;     //ADM7032Eڼ���Disable(���MӰ�ރw�؂�ւ�)
        delay_ms(1);    //DE���瑗�M�J�n�܂ł̳���
    }
    
    while((SSR10 & 0x0020) == 0x0020);  //�ޯ̧�󂫑҂�
    TXD2 = data;                        //���M�ް���������
    while((SSR10 & 0x0020) == 0x0020);  //�ޯ̧�]���҂�
    while((SSR10 & 0x0040) == 0x0040);  //���ڼ޽��]�������҂�
    
    if(con == 1) {
        DE_485 = 0;     //ADM7032E��ײ��Disable(��MӰ�ރw�؂�ւ�)
        RE_485 = 0;     //ADM7032Eڼ���Enable(��MӰ�ރw�؂�ւ�)
    }
    
    return(0);  
}
//***********************************************************
//��UART2�ɂ�镶����o��(RS-485)
//-----------------------------------------------------------
//  ���� tx_buf:���M������
//       con:RS-485����M�ؑ֐�����s����(0:����,1:�L��)
//-----------------------------------------------------------
//  �ߒl 0
//-----------------------------------------------------------
//***********************************************************
uint8_t uart2_puts(int8_t *data, uint8_t con)
{   
	int i;
    if(con == 1) {
        DE_485 = 1; //ADM7032E��ײ��Enable(���MӰ�ރw�؂�ւ�)
        RE_485 = 1; //ADM7032Eڼ���Disable(���MӰ�ރw�؂�ւ�)
        delay_ms(1);    //DE���瑗�M�J�n�܂ł̳���
    }
    
    while(*data != '\0'){
        while((SSR10 & 0x0020) == 0x0020);  //�ޯ̧�󂫑҂�
        TXD2 = *data++; //���M�ް���������		
    }
    while((SSR10 & 0x0020) == 0x0020);  //�ޯ̧�]���҂�
    while((SSR10 & 0x0040) == 0x0040);  //���ڼ޽��]�������҂�

    if(con == 1) {
        DE_485 = 0; //ADM7032E��ײ��Disable(��MӰ�ރw�؂�ւ�)
        RE_485 = 0; //ADM7032Eڼ���Enable(��MӰ�ރw�؂�ւ�)
    }
    
    return(0);
}


//**********************************************************
//�������𕶎���ϊ� uart2���當����o��
//----------------------------------------------------------
// uart2_pritnf()����Ăяo�����
//----------------------------------------------------------
//**********************************************************
void uart2_itoa(long val, signed char radix, signed char len)
{ 
    unsigned char c, r, sgn = 0, pad = ' ';
    unsigned char s[20], i = 0;
    long value = val;

    if (radix < 0) {
        radix = (int8_t)(-radix);
        if (val < 0) { 
            val = -val;
            sgn = '-';
        }
    }
    r = radix;
    if (len < 0) {
        len = (int8_t)(-len);
        pad = '0';
    }
    if (len > 20) return;
    do {
        c = (unsigned char)(val % r);
        if (c >= 10) c += 7;
        c += '0';
        s[i++] = c;
        val /= r;
    } while (val);

    if (pad ==' ' && sgn) s[i++] = sgn;
    if (pad =='0' && sgn) len--;
    while (i < len) s[i++] = pad;
    if (pad =='0' && sgn) s[i++] = sgn;

    do {
        R_Config_WDT_Restart();    //1s�ȓ��ɸر���邱��     
		//uart2_putc(s[--i],0);
        lcd_putc(s[--i]);
    }   while (i);  
}


//**********************************************************
//��UART2�ʐM�p�����t������o��
//----------------------------------------------------------  
//  UART2�ɐڑ����ꂽRS-485��ݼ���(ADM3072E)�O��̑���M����t��
//----------------------------------------------------------
//  ����
//   % �׸� ̨���ޕ� �ϊ��w�蕶����
//       |    |        |
//       |    |        + c: 1�����o��    s: ������o��
//     |    + 0�`19    d: 10�i�������L u: 10�i��������
//     |               X: 16�i��       b: 2�i��
//     + 0: 0�l��      l: long�^���� ex) %06ld
//----------------------------------------------------------  
//**********************************************************
void uart2_printf(int8_t *str, ...)
{
    va_list arp;
    int8_t d, r, w, s, l;
    int8_t *pt;
	volatile int i = 0;

    DE_485 = 1; //ADM7032E��ײ��Enable(���MӰ�ރw�؂�ւ�)
    RE_485 = 1; //ADM7032Eڼ���Disable(���MӰ�ރw�؂�ւ�)
    delay_ms(1);    //DE���瑗�M�J�n�܂ł̳���
            
    va_start(arp, str);

    while ((d = *str++) != 0) {
        R_Config_WDT_Restart();    //1s�ȓ��ɸر���邱��           
        if (d != '%') {
			//uart2_putc(d,0);
            lcd_putc(d);
			continue;
			 
        }
        d = *str++; w = r = s = l = 0;
        if (d == '0') {
            d = *str++; s = 1;
        }
        while ((d >= '0')&&(d <= '9')) {
            w += (int8_t)(w * 10 + (d - '0'));
            d = *str++;
        }
        if (s) w = (int8_t)(-w);
        if (d == 'l') {
            l = 1;
            d = *str++;
        }
        if (!d) break;
        if (d == 's') {
            pt = va_arg(arp, int8_t*);
			//uart2_puts(pt, 0); 
			
			//lcd_putc(*pt);
			for(i=0;i<40;i++){
				lcd_putc(*(pt+i));
			}
			
            continue;
        }
		
        if (d == 'c') {
            //uart2_putc((char)va_arg(arp, short), 0);
			lcd_putc((char)va_arg(arp, short));
            continue;
        }
        if (d == 'u') r = 10;
        if (d == 'd') r = -10;
        if (d == 'X') r = 16;
        if (d == 'o') r = 8;
        if (d == 'b') r = 2;
        if (!r) break;
        if (l) {
            uart2_itoa((long)va_arg(arp, long), r, w);
        } else {
            if (r > 0)
                uart2_itoa((unsigned long)va_arg(arp, unsigned short), r, w);
            else
                uart2_itoa((long)va_arg(arp, short), r, w);
        }
    }
    va_end(arp);
    
    DE_485 = 0; //ADM7032E��ײ��Disable(��MӰ�ރw�؂�ւ�)
    RE_485 = 0; //ADM7032Eڼ���Enable(��MӰ�ރw�؂�ւ�)
}

/************************************************************************/
// Function to write string value to the LCD.
/************************************************************************/
void display_itoa(long val, signed char radix, signed char len)
{ 
    unsigned char c, r, sgn = 0, pad = ' ';
    unsigned char s[20], i = 0;
    long value = val;

    if (radix < 0) {
        radix = (int8_t)(-radix);
        if (val < 0) { 
            val = -val;
            sgn = '-';
        }
    }
    r = radix;
    if (len < 0) {
        len = (int8_t)(-len);
        pad = '0';
    }
    if (len > 20) return;
    do {
        c = (unsigned char)(val % r);
        if (c >= 10) c += 7;
        c += '0';
        s[i++] = c;
        val /= r;
    } while (val);

    if (pad ==' ' && sgn) s[i++] = sgn;
    if (pad =='0' && sgn) len--;
    while (i < len) s[i++] = pad;
    if (pad =='0' && sgn) s[i++] = sgn;

    do {
        R_Config_WDT_Restart();    //1s�ȓ��ɸر���邱��     
        lcd_putc(s[--i]);
    }   while (i);  
}


//**********************************************************
//��UART2�ʐM�p�����t������o��
//----------------------------------------------------------  
//  UART2�ɐڑ����ꂽRS-485��ݼ���(ADM3072E)�O��̑���M����t��
//----------------------------------------------------------
//  ����
//   % �׸� ̨���ޕ� �ϊ��w�蕶����
//       |    |        |
//       |    |        + c: 1�����o��    s: ������o��
//     |    + 0�`19    d: 10�i�������L u: 10�i��������
//     |               X: 16�i��       b: 2�i��
//     + 0: 0�l��      l: long�^���� ex) %06ld
//----------------------------------------------------------  
//**********************************************************
void display_printf(int8_t *str, ...)
{
    va_list arp;
    int8_t d, r, w, s, l;
    int8_t *pt;
	volatile int i = 0;

    DE_485 = 1; //ADM7032E��ײ��Enable(���MӰ�ރw�؂�ւ�)
    RE_485 = 1; //ADM7032Eڼ���Disable(���MӰ�ރw�؂�ւ�)
    delay_ms(1);    //DE���瑗�M�J�n�܂ł̳���
            
    va_start(arp, str);

    while ((d = *str++) != 0) {
        R_Config_WDT_Restart();    //1s�ȓ��ɸر���邱��           
        if (d != '%') {
            lcd_putc(d);
			continue;
			 
        }
        d = *str++; w = r = s = l = 0;
        if (d == '0') {
            d = *str++; s = 1;
        }
        while ((d >= '0')&&(d <= '9')) {
            w += (int8_t)(w * 10 + (d - '0'));
            d = *str++;
        }
        if (s) w = (int8_t)(-w);
        if (d == 'l') {
            l = 1;
            d = *str++;
        }
        if (!d) break;
        if (d == 's') {
            pt = va_arg(arp, int8_t*);
			
			//lcd_putc(*pt);
			for(i=0;i< 15;i++){
				lcd_putc(*(pt+i));
			}
			
            continue;
        }
		
        if (d == 'c') {
			lcd_putc((char)va_arg(arp, short));
            continue;
        }
        if (d == 'u') r = 10;
        if (d == 'd') r = -10;
        if (d == 'X') r = 16;
        if (d == 'o') r = 8;
        if (d == 'b') r = 2;
        if (!r) break;
        if (l) {
            display_itoa((long)va_arg(arp, long), r, w);
        } else {
            if (r > 0)
                display_itoa((unsigned long)va_arg(arp, unsigned short), r, w);
            else
                display_itoa((long)va_arg(arp, short), r, w);
        }
    }
    va_end(arp);
    
    DE_485 = 0; //ADM7032E��ײ��Disable(��MӰ�ރw�؂�ւ�)
    RE_485 = 0; //ADM7032Eڼ���Enable(��MӰ�ރw�؂�ւ�)
}



/* End user code. Do not edit comment generated here */
