/********************************************************************************
* File Name    : r_cg_uarta_common.c
* Version      : 1.0.3
* Device(s)    : R7F100GLGxFB
* Description  : None
********************************************************************************/
/********************************************************************************
Includes
********************************************************************************/
#include "r_cg_macrodriver.h"
#include "r_cg_userdefine.h"
#include "Config_UARTA1.h"
#include "r_cg_uarta_common.h"

/********************************************************************************
Pragma directive
********************************************************************************/

/********************************************************************************
Global variables and functions
********************************************************************************/

/********************************************************************************
* Function Name: R_UARTA_Create
* Description  : This function enables UARTA0/UARTA1 input clock supply and
                 initializes UARTA0/UARTA1 module.
* Arguments    : None
* Return Value : None
********************************************************************************/
void R_UARTA_Create(void)
{
    UTAEN = 1U;    /* supply UARTA0/UARTA1 clock */
    /* Set UARTA0/UARTA1 settings */
    R_Config_UARTA1_Create();
}

/********************************************************************************
* Function Name: R_UARTA_Set_PowerOn
* Description  : This function starts the clock supply for UARTA0/UARTA1.
* Arguments    : None
* Return Value : None
********************************************************************************/
void R_UARTA_Set_PowerOn(void)
{
    UTAEN = 1U;    /* supply UARTA0,UARTA1 clock */
}

/********************************************************************************
* Function Name: R_UARTA_Set_PowerOff
* Description  : This function stops the clock supply for UARTA0/UARTA1.
* Arguments    : None
* Return Value : None
********************************************************************************/
void R_UARTA_Set_PowerOff(void)
{
    UTAEN = 0U;    /* stop UARTA0,UARTA1 clock */
}

