/*******************************************************************************
* File Name    : Config_UARTA1.h
* Version      : 1.1.0
* Device(s)    : R7F100GLGxFB
* Description  : This file implements device driver for Config_UARTA1.
********************************************************************************/

/*******************************************************************************
Includes
********************************************************************************/
#include "r_cg_uarta.h"

#ifndef CFG_Config_UARTA1_H
#define CFG_Config_UARTA1_H

/*******************************************************************************
Macro definitions (Register bit)
********************************************************************************/

/*******************************************************************************
Macro definitions
********************************************************************************/
#define _1A_UARTA_OUTPUT_BAUDRATE     (0x1AU)
#define _68_UARTA_OUTPUT_BAUDRATE     (0x68U)

/*******************************************************************************
Typedef definitions
********************************************************************************/
//UART�pFIFO�ޯ̧�\����
struct UARTA1_fifo{
    uint8_t idx_w;
    uint8_t idx_r;
    uint8_t count;
    uint8_t buff[120];    //FIFO�ޯ̧����120Byte
    uint8_t intr_on;
};

/*******************************************************************************
Global functions
********************************************************************************/
void R_Config_UARTA1_Create(void);
void R_Config_UARTA1_Start(void);
void R_Config_UARTA1_Stop(void);
MD_STATUS R_Config_UARTA1_Send(uint8_t * const tx_buf, uint16_t tx_num);
void R_Config_UARTA1_Loopback_Enable(void);
void R_Config_UARTA1_Loopback_Disable(void);
void R_Config_UARTA1_PollingEnd_UserCode(void);
void R_Config_UARTA1_Create_UserInit(void);

uint8_t UARTA1_getc(void);
uint8_t UARTA1_putc(uint8_t data);
uint8_t UARTA1_puts(int8_t *data);
void UARTA1_printf(int8_t *str, ...);
void UARTA1_itoa (long val, signed char radix, signed char len);

#endif
