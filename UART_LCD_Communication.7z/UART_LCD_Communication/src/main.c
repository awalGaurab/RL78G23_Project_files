/***********************************************************************/
/*                                                                     */
/*  FILE        :Main.c                                                */
/*  DATE        :                                                      */
/*  DESCRIPTION :Main Program                                          */
/*  CPU TYPE    :                                                      */
/*                                                                     */
/*  NOTE:THIS IS A TYPICAL EXAMPLE.                                    */
/*                                                                     */
/***********************************************************************/


/********************************************************************************
Includes
********************************************************************************/
#include <ctype.h>
#include <string.h>
#include "r_smc_entry.h"
#include "r_cg_uarta_common.h"
#include "Config_UARTA1.h"
#include "hd44780.h"

#include "r_cg_rtc.h" // added for rtc
/********************************************************************************
Global variables and functions
********************************************************************************/
extern struct UART0_fifo uart0_rxfifo;
extern struct UART2_fifo uart2_rxfifo;
extern struct UARTA1_fifo UARTA1_rxfifo;
extern volatile uint16_t G_usTimer;
extern volatile uint16_t G_msTimer;

#include <stdio.h> 

int8_t tx_str[40] = "Send string value to the lcd";
int8_t new_str = 10;
extern rtc_counter_value_t stRTC_Data;

void main(void);
void U0_montor(void);
void U2_montor(void);
void UA1_montor(void);
void delay_us(uint16_t aTimeUS);
void delay_ms(uint16_t aTimeMS);

void LCD_ini(void);
void lcd_write_4(uint8_t theByte);
void lcd_write_instruction_4d(uint8_t theInstruction);
void lcd_write_string_4d(uint8_t theString[]);
void lcd_write_character_4d(uint8_t theData);

// LCD instructions
#define lcd_Clear           0b00000001          // replace all characters with ASCII 'space'
#define lcd_Home            0b00000010          // return cursor to first position on first line
#define lcd_EntryMode       0b00000110          // shift cursor from left to right on read/write
#define lcd_DisplayOff      0b00001000          // turn display off
#define lcd_DisplayOn       0b00001100          // display on, cursor off, don't blink character
#define lcd_FunctionReset   0b00110000          // reset the LCD
#define lcd_FunctionSet4bit 0b00101000          // 4-bit data, 2-line display, 5 x 7 font
#define lcd_SetCursor       0b10000000          // set cursor position

/********************************************************************************
* Function Name: main
* Description  : This function main.
* Arguments    : None
* Return Value : None
********************************************************************************/
void main(void)
{
    R_UARTA_Set_PowerOn();
    R_Config_UARTA1_Create();

    R_Config_UART0_Start();
    R_Config_UART2_Start();
    R_Config_UARTA1_Start();
    EI();
	
    P5_bit.no3 = 0;
	
	R_RTC_Set_RTC1HZOn();
	R_RTC_Start();
	
    uart0_puts("\r\n*** RL78/G23-64p FPB uart0 monitor ***\r\n");
    uart2_puts("\r\n*** RL78/G23-64p FPB uart2 monitor ***\r\n",1);
    UARTA1_puts("\r\n*** RL78/G23-64p FPB uartA1 monitor ***\r\n");

    LCD_ini();
	
	lcd_write_instruction_4d(lcd_Clear);
	delay_ms(1000);
    //lcd_write_string_4d("LCD TEST");
	
	uart2_printf("%X",new_str);
	lcd_locate(1,0);
	uart2_printf("O/P:%s",tx_str);
	
	
	//lcd_write_string_4d("SECOND LINE DATA");	
	
	//lcd_init();
	//lcd_putc('A');
	//lcd_putc('B');
 	
    while(1){
        //R_Config_WDT_Restart();
        P5_bit.no2 = P13_bit.no7;
        U0_montor();
        U2_montor();
        UA1_montor();	
		
    }
}

void LCD_ini(void)
{
    delay_ms(80);
    P14_bit.no0 = 0;    // rs:low
    P14_bit.no1 = 0;    // e :low

    lcd_write_4(lcd_FunctionReset);     // first part of reset sequence
    delay_ms(10);

    lcd_write_4(lcd_FunctionReset);     // second part of reset sequence
    delay_us(200);

    lcd_write_4(lcd_FunctionReset);     // third part of reset sequence
    delay_us(200);

    lcd_write_4(lcd_FunctionSet4bit);   // set 4-bit mode
    delay_us(80);

    lcd_write_instruction_4d(lcd_FunctionSet4bit);   // set mode, lines, and font
    delay_us(80);

    lcd_write_instruction_4d(lcd_DisplayOff);      // turn display OFF
    delay_us(80);                                  // 40uS delay (min)

    lcd_write_instruction_4d(lcd_Clear);             // clear display RAM
    delay_ms(4);                                   // 1.64 mS delay (min)

    lcd_write_instruction_4d(lcd_EntryMode);         // set desired shift characteristics
    delay_us(80);                                  // 40uS delay (min)

    lcd_write_instruction_4d(lcd_DisplayOn);         // turn the display ON
    delay_us(80);                                  // 40uS delay (min)
}

void lcd_write_instruction_4d(uint8_t theInstruction)
{
    P14_bit.no0 = 0;                // select the Instruction Register (RS low)
    P14_bit.no1 = 0;                // make sure E is initially low
    lcd_write_4(theInstruction);    // write the upper 4-bits of the data
    lcd_write_4(theInstruction << 4); // write the lower 4-bits of the data
}

void lcd_write_4(uint8_t theByte)
{
    P5_bit.no2 = (theByte >> 4) & 0x01;
    P5_bit.no3 = (theByte >> 5) & 0x01;
    P5_bit.no4 = (theByte >> 6) & 0x01;
    P5_bit.no5 = (theByte >> 7) & 0x01;
    P14_bit.no1 = 1;    // e :high
    delay_us(10);
    P14_bit.no1 = 0;    // e :low
    delay_us(10);
}

void lcd_write_string_4d(uint8_t theString[])
{
    volatile int i = 0;              // character counter*/
    while (theString[i] != 0)
    {
        lcd_write_character_4d(theString[i]);
        i++;
        delay_us(80);                // 40 uS delay (min)
    }
}

void lcd_write_character_4d(uint8_t theData)
{
    P14_bit.no0 = 1;                // select the Instruction Register (RS high)
    P14_bit.no1 = 0;                // make sure E is initially low
    lcd_write_4(theData);           // write the upper 4-bits of the data
    lcd_write_4(theData << 4);      // write the lower 4-bits of the data
}


void U0_montor(void)
{
    static int8_t cmd_str[30];
    static int8_t idx = 0;
    uint8_t c;
    uint8_t *ptr;
    
    if(uart0_rxfifo.count == 0) return;
    c = uart0_getc();
    if ((c == '\b') && idx) {
        idx--; uart0_putc(c);
    }
    if ((c >= ' ') && (idx < 29)) {
        cmd_str[idx++] = toupper(c);
        uart0_putc(c);
    }
    if (c == '\r'){
        cmd_str[idx] = 0;
        idx = 0;
        uart0_putc('\n');
        ptr = cmd_str;
        
        if(strstr(cmd_str,"HELP") != 0) {      // ����ވꗗ
            uart0_printf("u0_command list\n");
        }
		else {
			uart0_printf("\r%s\r\n\r\n",cmd_str);
		}
    }
}

void U2_montor(void)
{
    static int8_t cmd_str[30];
    static int8_t idx = 0;
    uint8_t c;
    uint8_t *ptr;
    
    if(uart2_rxfifo.count == 0) return;
    c = uart2_getc();
    if ((c == '\b') && idx) {
        idx--; uart2_putc(c,1);
    }
    if ((c >= ' ') && (idx < 29)) {
        cmd_str[idx++] = toupper(c);
        uart2_putc(c,1);
    }
    if (c == '\r'){
        cmd_str[idx] = 0;
        idx = 0;
        uart2_putc('\n',1);
        ptr = cmd_str;
        
        if(strstr(cmd_str,"HELP") != 0) {      // ����ވꗗ
            uart2_printf("u2_command list\n");
        }
		else {
			uart2_printf("\r%s\r\n\r\n",cmd_str);
		}
    }
}

void UA1_montor(void)
{
    static int8_t cmd_str[30];
    static int8_t idx = 0;
    uint8_t c;
    uint8_t *ptr;
    
    if(UARTA1_rxfifo.count == 0) return;
    c = UARTA1_getc();
    if ((c == '\b') && idx) {
        idx--; UARTA1_putc(c);
    }
    if ((c >= ' ') && (idx < 29)) {
        cmd_str[idx++] = toupper(c);
        UARTA1_putc(c);
    }
    if (c == '\r'){
        cmd_str[idx] = 0;
        idx = 0;
        UARTA1_putc('\n');
        ptr = cmd_str;
        
        if(strstr(cmd_str,"HELP") != 0) {      // ����ވꗗ
            UARTA1_printf("UA1_command list\n");
        }
		else {
			UARTA1_printf("\r%s\r\n\r\n",cmd_str);
		}
    }
}


void delay_us(uint16_t aTimeUS)
{
    G_usTimer = 0;
    //R_Config_ITL000_Start();
    R_Config_TAU0_1_Start();
    while(G_usTimer < aTimeUS);
    //R_Config_ITL000_Stop();
    R_Config_TAU0_1_Stop();
}

void delay_ms(uint16_t aTimeMS)
{
    uint16_t i;
    for(i=0; i<=aTimeMS; i++){
        delay_us(1000);
        R_Config_WDT_Restart();
    }
        
    //G_msTimer = 0;
    //R_Config_ITL001_Start();
    //while(G_msTimer < aTimeMS);
    //R_Config_ITL001_Stop();
}
