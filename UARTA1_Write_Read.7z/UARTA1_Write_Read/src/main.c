/***********************************************************************/
/*                                                                     */
/*  FILE        :Main.c                                                */
/*  DATE        :                                                      */
/*  DESCRIPTION :Main Program                                          */
/*  CPU TYPE    :                                                      */
/*                                                                     */
/*  NOTE:THIS IS A TYPICAL EXAMPLE.                                    */
/*                                                                     */
/***********************************************************************/


/********************************************************************************
Includes
********************************************************************************/
#include "r_smc_entry.h"
#include "Config_UART2.h"
#include "r_cg_uarta_common.h"
#include "r_cg_uarta.h"
#include "Config_UARTA1.h"
#include <string.h>

/********************************************************************************
Global variables and functions
********************************************************************************/
extern struct UART2_fifo uart2_rxfifo;
extern struct UARTA1_fifo UARTA1_rxfifo;

void main(void);
void U2_montor(void);
void UA1_montor(void);

/********************************************************************************
* Function Name: main
* Description  : This function main.
* Arguments    : None
* Return Value : None
********************************************************************************/
void main(void)
{
    //R_Config_UART2_Create();
    //R_Config_UART2_Start();
    R_UARTA_Set_PowerOn();
    R_Config_UARTA1_Create();
    R_Config_UARTA1_Start();
    EI();
    P5_bit.no3 = 0;
    //UARTA1_puts("\r\n*** RL78/G23-64p FPB ***\r\n",1);
    UARTA1_puts("\r\n*** RL78/G23-64p FPB ***\r\n");
	
    while(1){
        R_Config_WDT_Restart();
        P5_bit.no2 = P13_bit.no7;
        //U2_montor();
        UA1_montor();
    }
}

void U2_montor(void)
{
    static int8_t cmd_str[30];
    static int8_t idx = 0;
    uint8_t c;
    uint8_t *ptr;
    
    if(uart2_rxfifo.count == 0) return;
    c = uart2_getc();
    if ((c == '\b') && idx) {
        idx--; uart2_putc(c,1);
    }
    if ((c >= ' ') && (idx < 29)) {
        cmd_str[idx++] = toupper(c);
        uart2_putc(c,1);
    }
    if (c == '\r'){
        cmd_str[idx] = 0;
        idx = 0;
        uart2_putc('\n',1);
        ptr = cmd_str;
        
        if(strstr(cmd_str,"HELP") != 0) {      // ����ވꗗ
            uart2_printf("u2_command list\r\n");
        }
    }

}

void UA1_montor(void)
{
    static int8_t cmd_str[30];
    static int8_t idx = 0;
    uint8_t c;
    uint8_t *ptr;
    
    if(UARTA1_rxfifo.count == 0) return;
    c = UARTA1_getc();
    if ((c == '\b') && idx) {
        idx--; UARTA1_putc(c);
    }
    if ((c >= ' ') && (idx < 29)) {
        cmd_str[idx++] = toupper(c);
        UARTA1_putc(c);
    }
    if (c == '\r'){
        cmd_str[idx] = 0;
        idx = 0;
        UARTA1_putc('\n');
        ptr = cmd_str;
        
        if(strstr(cmd_str,"HELP") != 0) {      // ����ވꗗ
            UARTA1_printf("\rUA1_command list\r\n\r\n");
        }
		else {
			UARTA1_printf("\r%s\r\n\r\n",cmd_str);
		}
    }
}
