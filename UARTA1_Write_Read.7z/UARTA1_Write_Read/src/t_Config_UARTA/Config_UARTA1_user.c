/********************************************************************************
* File Name    : Config_UARTA1_user.c
* Version      : 1.1.0
* Device(s)    : R7F100GLGxFB
* Description  : This file implements device driver for Config_UARTA1.
********************************************************************************/
/********************************************************************************
Includes
********************************************************************************/
#include "r_cg_macrodriver.h"
#include "r_cg_userdefine.h"
#include "Config_UARTA1.h"
#include <stdarg.h>

/********************************************************************************
Pragma directive
********************************************************************************/
#pragma interrupt r_Config_UARTA1_interrupt_receive(vect=INTUR1)
#pragma interrupt r_Config_UARTA1_interrupt_error(vect=INTURE1)

/********************************************************************************
Global variables and functions
********************************************************************************/
struct UARTA1_fifo UARTA1_rxfifo;

/********************************************************************************
* Function Name: R_Config_UARTA1_Create_UserInit
* Description  : This function adds user code after initializing UARTA1.
* Arguments    : None
* Return Value : None
********************************************************************************/
void R_Config_UARTA1_Create_UserInit(void)
{
}

/********************************************************************************
* Function Name: R_Config_UARTA1_PollingEnd_UserCode
* Description  : This function is a callback function when UARTA1 finishes polling
                 transmission.
* Arguments    : None
* Return Value : None
*********************************************************************************/
void R_Config_UARTA1_PollingEnd_UserCode(void)
{
}

/********************************************************************************
* Function Name: r_Config_UARTA1_callback_error
* Description  : This function is a callback function when UARTA1 reception error occurs.
* Arguments    : err_type -
*                     error type value
* Return Value : None
*********************************************************************************/
static void r_Config_UARTA1_callback_error(uint8_t err_type)
{
    /* Start user code for r_Config_UARTA1_callback_error. Do not edit comment generated here */
    /* End user code. Do not edit comment generated here */
}

/********************************************************************************
* Function Name: r_Config_UARTA1_interrupt_error
* Description  : This function is UARTA1 error interrupt service routine.
* Arguments    : None
* Return Value : None
*********************************************************************************/
static void __near r_Config_UARTA1_interrupt_error(void)
{
    uint8_t err_type;

    err_type = (ASISA1 & (_04_UARTA_PARITY_ERROR_DETECTED | _02_UARTA_FRAME_ERROR_DETECTED | 
               _01_UARTA_OVERRUN_ERROR_DETECTED));
    ASCTA1 |= (_04_UARTA_PARITY_FLAG_CLEAR | _02_UARTA_FRAME_FLAG_CLEAR | _01_UARTA_OVERRUN_FLAG_CLEAR);
    r_Config_UARTA1_callback_error(err_type);
}

//*****************************************************
// UARTA1���䕔
//*****************************************************

//*****************************************************
//��UARTA1��M�ݸ��ޯ̧�֊i�[
//-----------------------------------------------------
// ��M�����ݏ��� ��M�ݸ��ޯ̧�֊i�[
//-----------------------------------------------------
//*****************************************************
//void r_UARTA1_int_recv(uint16_t rx_data)
static void __near r_Config_UARTA1_interrupt_receive(void)
{
    uint8_t n, i;

    n = UARTA1_rxfifo.count;
    if(n < sizeof(UARTA1_rxfifo.buff)) {
        UARTA1_rxfifo.count = ++n;
        i = UARTA1_rxfifo.idx_w;
        UARTA1_rxfifo.buff[i++] = RXBA1;
        if(i >= sizeof(UARTA1_rxfifo.buff))
            i = 0;
        UARTA1_rxfifo.idx_w = i;
    }
}
//*****************************************************
//��UARTA1��M�ޯ̧����1������o
//-----------------------------------------------------
// �ߒl d:�擾�ް�
//-----------------------------------------------------
//*****************************************************
uint8_t UARTA1_getc(void)
{
    uint8_t d, i;

    i = UARTA1_rxfifo.idx_r;
    while(UARTA1_rxfifo.count == 0);
    d = UARTA1_rxfifo.buff[i++];
    DI();   //���荞�݋֎~
    UARTA1_rxfifo.count--;
    EI();   //���荞�݋���
    if(i >= sizeof(UARTA1_rxfifo.buff))
        i = 0;
    UARTA1_rxfifo.idx_r = i;

    return d;
}
//*****************************************************
//��UARTA1�ɂ��1�o�C�g�o��
//-----------------------------------------------------
// ���� s:�o�͒l
//-----------------------------------------------------
// �ߒl 0
//-----------------------------------------------------

//*****************************************************
uint8_t UARTA1_putc(uint8_t data)
{
    while (0U != (ASISA1 & _20_UARTA_DATA_EXIST_IN_TXBA))
    {
        ;           // �ޯ̧�󂫑҂�
    }
    TXBA1 = data;   // ���M�f�[�^��������
    while (0U != (ASISA1 & _10_UARTA_HAVE_NEXT_TRANSFER))
    {
        ;           // ���ڼ޽����M�����҂�
    }
    return(0);  
}
//***********************************************************
//��UARTA1�ɂ�镶����o��
//-----------------------------------------------------------
//  ���� tx_buf:���M������
//-----------------------------------------------------------
//  �ߒl 0
//-----------------------------------------------------------
//***********************************************************
uint8_t UARTA1_puts(int8_t *data)
{       
    while(*data != '\0'){
        while (0U != (ASISA1 & _20_UARTA_DATA_EXIST_IN_TXBA))
        {
            ;            // �ޯ̧�󂫑҂�
        }
        TXBA1 = *data++; // ���M�ް���������
    }
    while (0U != (ASISA1 & _10_UARTA_HAVE_NEXT_TRANSFER))
    {
        ;                // ���ڼ޽����M�����҂�
    }
    return(0);
}
//**********************************************************
//��UARTA1�ʐM�p�����t������o��
//----------------------------------------------------------  
//  ����
//   % �׸� ̨���ޕ� �ϊ��w�蕶����
//       |    |        |
//       |    |        + c: 1�����o��    s: ������o��
//     |    + 0�`19    d: 10�i�������L u: 10�i��������
//     |               X: 16�i��       b: 2�i��
//     + 0: 0�l��      l: long�^���� ex) %06ld
//----------------------------------------------------------  
//**********************************************************
void UARTA1_printf(int8_t *str, ...)
{
    va_list arp;
    int8_t d, r, w, s, l;
    int8_t *pt;

//[CcnvCA78K0R]     va_starttop(arp, str);
    va_start(arp, str);

    while ((d = *str++) != 0) {
        if (d != '%') {
            UARTA1_putc(d); continue;
        }
        d = *str++; w = r = s = l = 0;
        if (d == '0') {
            d = *str++; s = 1;
        }
        while ((d >= '0')&&(d <= '9')) {
            w += (int8_t)(w * 10 + (d - '0'));
            d = *str++;
        }
        if (s) w = (int8_t)(-w);
        if (d == 'l') {
            l = 1;
            d = *str++;
        }
        if (!d) break;
        if (d == 's') {
            pt = va_arg(arp, int8_t*);
            UARTA1_puts(pt);
            continue;
        }
        if (d == 'c') {
            UARTA1_putc((char)va_arg(arp, short));
            continue;
        }
        if (d == 'u') r = 10;
        if (d == 'd') r = -10;
        if (d == 'X') r = 16;
        if (d == 'b') r = 2;
        if (d == 'o') r = 8;
        if (!r) break;
        if (l) {
            UARTA1_itoa((long)va_arg(arp, long), r, w);
        } else {
            if (r > 0)
                UARTA1_itoa((unsigned long)va_arg(arp, unsigned short), r, w);
            else
                UARTA1_itoa((long)va_arg(arp, short), r, w);
        }
    }
    va_end(arp);
}
//**********************************************************
//�������𕶎���ϊ� UARTA1���當����o��
//----------------------------------------------------------
// UARTA1_pritnf(),hart_pritnf()����Ăяo�����
//----------------------------------------------------------
//**********************************************************
void UARTA1_itoa (long val, signed char radix, signed char len)
{
    
    unsigned char c, r, sgn = 0, pad = ' ';
    unsigned char s[20], i = 0;
    long value = val;

    if (radix < 0) {
        radix = (int8_t)(-radix);
        if (val < 0) { 
            val = -val;
            sgn = '-';
        }
    }
    r = radix;
    if (len < 0) {
        len = (int8_t)(-len);
        pad = '0';
    }
    if (len > 20) return;
    do {
        c = (unsigned char)(val % r);
        if (c >= 10) c += 7;
        c += '0';
        s[i++] = c;
        val /= r;
    } while (val);

    if (pad ==' ' && sgn) s[i++] = sgn;
    if (pad =='0' && sgn) len--;
    while (i < len) s[i++] = pad;
    if (pad =='0' && sgn) s[i++] = sgn;

    do
        UARTA1_putc(s[--i]);
    while (i);  
}

