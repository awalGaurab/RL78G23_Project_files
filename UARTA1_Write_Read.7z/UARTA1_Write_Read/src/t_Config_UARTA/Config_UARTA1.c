/********************************************************************************
* File Name    : Config_UARTA1.c
* Version      : 1.1.0
* Device(s)    : R7F100GLGxFB
* Description  : This file implements device driver for Config_UARTA1.
********************************************************************************/
/********************************************************************************
Includes
********************************************************************************/
#include "r_cg_macrodriver.h"
#include "r_cg_userdefine.h"
#include "Config_UARTA1.h"

/********************************************************************************
Pragma directive
********************************************************************************/

/********************************************************************************
Global variables and functions
********************************************************************************/

/********************************************************************************
* Function Name: R_Config_UARTA1_Create
* Description  : This function initializes the UARTA1 module.
* Arguments    : None
* Return Value : None
********************************************************************************/
void R_Config_UARTA1_Create(void)
{
    UARTAEN1 = 0U;
    UTMK1 = 1U;    /* disable INTUT1 interrupt */
    UTIF1 = 0U;    /* clear INTUT1 interrupt flag */
    URMK1 = 1U;    /* disable INTUR1 interrupt */
    URIF1 = 0U;    /* clear INTUR1 interrupt flag */
    UREMK1 = 1U;    /* disable INTURE1 interrupt */
    UREIF1 = 0U;    /* clear INTURE1 interrupt flag */
    /* Set INTUT1 low priority */
    UTPR11 = 1U;
    UTPR01 = 1U;
    /* Set INTUR1 low priority */
    URPR11 = 1U;
    URPR01 = 1U;
    /* Set INTURE1 low priority */
    UREPR11 = 1U;
    UREPR01 = 1U;
    BRGCA1 = _68_UARTA_OUTPUT_BAUDRATE;
    ASIMA11 = _00_UARTA_PARITY_NONE | _18_UARTA_TRANSFER_LENGTH_8 | _00_UARTA_STOP_BIT_1 | _02_UARTA_DIRECTION_LSB | 
              _00_UARTA_DATA_NORMAL;
    ASIMA10 = _00_UARTA_TRANSFER_END | _01_UARTA_INTUR_OCCUR;
    UTA0CK |= _20_UARTA_FSEL_SELECT_FIHP;
    UTA1CK = _00_UARTA_CLKA1_OUTPUT_DISABLE | _00_UARTA1_SELECT_FSEL;
    /* Set TxDA1 pin */
    P4 |= 0x04U;
    PM4 &= 0xFBU;
    /* Set RxDA1 pin */
    PM4 |= 0x02U;

    R_Config_UARTA1_Create_UserInit();
}

/********************************************************************************
* Function Name: R_Config_UARTA1_Start
* Description  : This function starts UARTA1 module operation.
* Arguments    : None
* Return Value : None
********************************************************************************/
void R_Config_UARTA1_Start(void)
{
    volatile uint8_t w_count;

    URIF1 = 0U;    /* clear INTUR1 interrupt flag */
    UREIF1 = 0U;    /* clear INTURE1 interrupt flag */
    URMK1 = 0U;    /* enable INTUR1 interrupt */
    UREMK1 = 0U;    /* enable INTURE1 interrupt */
    UARTAEN1 = 1U;
    TXEA1 = 1U;

    /* Change the waiting time according to the system */
    for (w_count = 0U; w_count <= 1U; w_count++)
    {
        NOP();
    }
    RXEA1 = 1U;
}

/********************************************************************************
* Function Name: R_Config_UARTA1_Stop
* Description  : This function stops UARTA1 module operation.
* Arguments    : None
* Return Value : None
********************************************************************************/
void R_Config_UARTA1_Stop(void)
{
    URMK1 = 1U;    /* disable INTUR1 interrupt */
    UREMK1 = 1U;    /* disable INTURE1 interrupt */
    URIF1 = 0U;    /* clear INTUR1 interrupt flag */
    UREIF1 = 0U;    /* clear INTURE1 interrupt flag */
    TXEA1 = 0U;
    RXEA1 = 0U;
    UARTAEN1 = 0U;
}

/********************************************************************************
* Function Name: R_Config_UARTA1_Send
* Description  : This function sends UARTA1 data.
* Arguments    : tx_buf -
*                    transfer buffer pointer
*                tx_num -
*                    buffer size
* Return Value : status -
*                    MD_OK or MD_ARGERROR
********************************************************************************/
MD_STATUS R_Config_UARTA1_Send(uint8_t * const tx_buf, uint16_t tx_num)
{
    MD_STATUS status = MD_OK;
    uint8_t * tx_address;
    uint16_t tx_count;

    if (tx_num < 1U)
    {
        status = MD_ARGERROR;
    }
    else
    {
        /* Disable UARTA1 interrupt operation */
        UTMK1 = 1U;
        tx_address = tx_buf;
        tx_count = tx_num;

        while (0U < tx_count)
        {
            while (0U != (ASISA1 & _20_UARTA_DATA_EXIST_IN_TXBA))
            {
                ;
            }

            TXBA1 = *tx_address;
            tx_count--;
            tx_address++;
        }

        while (0U != (ASISA1 & _10_UARTA_HAVE_NEXT_TRANSFER))
        {
            ;
        }

        R_Config_UARTA1_PollingEnd_UserCode();
    }

    return (status);
}

/********************************************************************************
* Function Name: R_Config_UARTA1_Loopback_Enable
* Description  : This function enables the UARTA1 loopback function.
* Arguments    : None
* Return Value : None
********************************************************************************/
void R_Config_UARTA1_Loopback_Enable(void)
{
    ULBS5 = 1U;
}

/********************************************************************************
* Function Name: R_Config_UARTA1_Loopback_Disable
* Description  : This function disables the UARTA1 loopback function.
* Arguments    : None
* Return Value : None
********************************************************************************/
void R_Config_UARTA1_Loopback_Disable(void)
{
    ULBS5 = 0U;
}

