/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability 
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : Config_UART0_user.c
* Version      : 1.1.0
* Device(s)    : R7F100GLGxFB
* Description  : This file implements device driver for Config_UART0.
***********************************************************************************************************************/
/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "r_cg_userdefine.h"
#include "Config_UART0.h"
/* Start user code for include. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
#pragma interrupt r_Config_UART0_interrupt_send(vect=INTST0)
#pragma interrupt r_Config_UART0_interrupt_receive(vect=INTSR0)
#pragma interrupt r_Config_UART0_interrupt_error(vect=INTSRE0)
/* Start user code for pragma. Do not edit comment generated here */
void r_uart0_int_recv(uint16_t rx_data);
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
extern volatile uint8_t * gp_uart0_tx_address;    /* uart0 transmit buffer address */
extern volatile uint16_t g_uart0_tx_count;        /* uart0 transmit data number */
extern volatile uint8_t * gp_uart0_rx_address;    /* uart0 receive buffer address */
extern volatile uint16_t g_uart0_rx_count;        /* uart0 receive data number */
extern volatile uint16_t g_uart0_rx_length;       /* uart0 receive data length */
/* Start user code for global. Do not edit comment generated here */
struct UART0_fifo uart0_rxfifo;
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_UART0_Create_UserInit
* Description  : This function adds user code after initializing UART0.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_UART0_Create_UserInit(void)
{
    /* Start user code for user init. Do not edit comment generated here */
    /* End user code. Do not edit comment generated here */
}

/***********************************************************************************************************************
* Function Name: r_Config_UART0_callback_sendend
* Description  : This function is a callback function when UART0 finishes transmission.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static void r_Config_UART0_callback_sendend(void)
{
    /* Start user code for r_Config_UART0_callback_sendend. Do not edit comment generated here */
    /* End user code. Do not edit comment generated here */
}

/***********************************************************************************************************************
* Function Name: r_Config_UART0_callback_receiveend
* Description  : This function is a callback function when UART0 finishes reception.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static void r_Config_UART0_callback_receiveend(void)
{
    /* Start user code for r_Config_UART0_callback_receiveend. Do not edit comment generated here */
    /* End user code. Do not edit comment generated here */
}

/***********************************************************************************************************************
* Function Name: r_Config_UART0_callback_error
* Description  : This function is a callback function when UART0 reception error occurs.
* Arguments    : err_type -
*                    error type info
* Return Value : None
***********************************************************************************************************************/
static void r_Config_UART0_callback_error(uint8_t err_type)
{
    /* Start user code for r_Config_UART0_callback_error. Do not edit comment generated here */
    /* End user code. Do not edit comment generated here */
}

/***********************************************************************************************************************
* Function Name: r_Config_UART0_callback_softwareoverrun
* Description  : This function is a callback when UART0 receives an overflow data.
* Arguments    : rx_data -
*                    receive data
* Return Value : None
***********************************************************************************************************************/
static void r_Config_UART0_callback_softwareoverrun(uint16_t rx_data)
{
    /* Start user code for r_Config_UART0_callback_softwareoverrun. Do not edit comment generated here */
    /* End user code. Do not edit comment generated here */
}

/***********************************************************************************************************************
* Function Name: r_Config_UART0_interrupt_send
* Description  : This function is UART0 send interrupt service routine.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static void __near r_Config_UART0_interrupt_send(void)
{
    if (g_uart0_tx_count > 0U)
    {
        TXD0 = *gp_uart0_tx_address;
        gp_uart0_tx_address++;
        g_uart0_tx_count--;
    }
    else
    {
        r_Config_UART0_callback_sendend();
    }
}

/***********************************************************************************************************************
* Function Name: r_Config_UART0_interrupt_receive
* Description  : This function is UART0 receive interrupt service routine.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static void __near r_Config_UART0_interrupt_receive(void)
{
    uint8_t rx_data;

    rx_data = RXD0;

    if (g_uart0_rx_length > g_uart0_rx_count)
    {
        *gp_uart0_rx_address = rx_data;
        gp_uart0_rx_address++;
        g_uart0_rx_count++;

        if (g_uart0_rx_length == g_uart0_rx_count)
        {
            r_Config_UART0_callback_receiveend();
        }
    }
    else
    {
        r_Config_UART0_callback_softwareoverrun(rx_data);
    }
}

/***********************************************************************************************************************
* Function Name: r_Config_UART0_interrupt_error
* Description  : This function is UART0 error interrupt service routine.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static void __near r_Config_UART0_interrupt_error(void)
{
    uint8_t err_type;

    *gp_uart0_rx_address = RXD0;
    err_type = (uint8_t)(SSR01 & 0x0007U);
    SIR01 = (uint16_t)err_type;
    r_Config_UART0_callback_error(err_type);
}

/* Start user code for adding. Do not edit comment generated here */

void r_uart0_int_recv(uint16_t rx_data)
{
    uint8_t n, i;

    if(((uint8_t)rx_data > 0) && ((uint8_t)rx_data < 0x80)) {
        n = uart0_rxfifo.count;
        if(n < sizeof(uart0_rxfifo.buff)) {
            uart0_rxfifo.count = ++n;
            i = uart0_rxfifo.idx_w;
            uart0_rxfifo.buff[i++] = (uint8_t)rx_data;
            if(i >= sizeof(uart0_rxfifo.buff))
                i = 0;
            uart0_rxfifo.idx_w = i;
        }
    }
}
//*****************************************************
//??UART2?o?MET�PI��?c?c1?��???a?o(RS-485)
//-----------------------------------------------------
// ?s�fl d:?a�g?AT��A
//-----------------------------------------------------
//*****************************************************
uint8_t uart0_getc(void)
{
    uint8_t d, i;

    i = uart0_rxfifo.idx_r;
    while(uart0_rxfifo.count == 0);
    d = uart0_rxfifo.buff[i++];
    DI();   //???e???Y?O?~
    uart0_rxfifo.count--;
    EI();   //???e???Y??��A
    if(i >= sizeof(uart0_rxfifo.buff))
        i = 0;
    uart0_rxfifo.idx_r = i;

    return d;
}
//*****************************************************
//??UART2?E?a?e1?o?C?g?o?I(RS-485)
//-----------------------------------------------------
// ?o?�h data:?o?I�fl
//      con:RS-485�e??o?M?O�eO?��?a?d?s???c(0:?3?��,1:?L?e)
//-----------------------------------------------------
// ?s�fl 0
//-----------------------------------------------------
//*****************************************************
uint8_t uart0_putc(uint8_t data, uint8_t con)
{
    if(con == 1) {
        DE_485 = 1;     //ADM7032EAT�~2ETEnable(�e??MO��AT?w?O?e�eO?|)
        RE_485 = 1;     //ADM7032EU?��ETDisable(�e??MO��AT?w?O?e�eO?|)
        //delay_ms(1);    //DE?c?c�e??M?J?n?U?A?I3a2A
    }
    
    while((SSR10 & 0x0020) == 0x0020);  //ET�PI��?o?��eO??
    TXD0 = data;                        //�e??MAT��A?�e?��???Y
    while((SSR10 & 0x0020) == 0x0020);  //ET�PI���g]�e?�eO??
    while((SSR10 & 0x0040) == 0x0040);  //?IAU?T?A�g]�e??R?1�eO??
    
    if(con == 1) {
        DE_485 = 0;     //ADM7032EAT�~2ETDisable(?o?MO��AT?w?O?e�eO?|)
        RE_485 = 0;     //ADM7032EU?��ETEnable(?o?MO��AT?w?O?e�eO?|)
    }
    
    return(0);  
}
//***********************************************************
//??UART2?E?a?e?��???n?o?I(RS-485)
//-----------------------------------------------------------
//  ?o?�h tx_buf:�e??M?��???n
//       con:RS-485�e??o?M?O�eO?��?a?d?s???c(0:?3?��,1:?L?e)
//-----------------------------------------------------------
//  ?s�fl 0
//-----------------------------------------------------------
//***********************************************************
uint8_t uart0_puts(int8_t *data, uint8_t con)
{   
    if(con == 1) {
        DE_485 = 1; //ADM7032EAT�~2ETEnable(�e??MO��AT?w?O?e�eO?|)
        RE_485 = 1; //ADM7032EU?��ETDisable(�e??MO��AT?w?O?e�eO?|)
        //delay_ms(1);    //DE?c?c�e??M?J?n?U?A?I3a2A
    }
    
    while(*data != '\0'){
        while((SSR10 & 0x0020) == 0x0020);  //ET�PI��?o?��eO??
        TXD0 = *data++; //�e??MAT��A?�e?��???Y
    }
    while((SSR10 & 0x0020) == 0x0020);  //ET�PI���g]�e?�eO??
    while((SSR10 & 0x0040) == 0x0040);  //?IAU?T?A�g]�e??R?1�eO??

    if(con == 1) {
        DE_485 = 0; //ADM7032EAT�~2ETDisable(?o?MO��AT?w?O?e�eO?|)
        RE_485 = 0; //ADM7032EU?��ETEnable(?o?MO��AT?w?O?e�eO?|)
    }
    
    return(0);
}

//**********************************************************
//???R?�h?d?��???n?I?�E uart2?c?c?��???n?o?I
//----------------------------------------------------------
// uart2_pritnf()?c?c?A?N?o?3?e?e
//----------------------------------------------------------
//**********************************************************
void uart0_itoa(long val, signed char radix, signed char len)
{
    
    unsigned char c, r, sgn = 0, pad = ' ';
    unsigned char s[20], i = 0;
    long value = val;

    if (radix < 0) {
        radix = (int8_t)(-radix);
        if (val < 0) { 
            val = -val;
            sgn = '-';
        }
    }
    r = radix;
    if (len < 0) {
        len = (int8_t)(-len);
        pad = '0';
    }
    if (len > 20) return;
    do {
        c = (unsigned char)(val % r);
        if (c >= 10) c += 7;
        c += '0';
        s[i++] = c;
        val /= r;
    } while (val);

    if (pad ==' ' && sgn) s[i++] = sgn;
    if (pad =='0' && sgn) len--;
    while (i < len) s[i++] = pad;
    if (pad =='0' && sgn) s[i++] = sgn;

    do {
        R_Config_WDT_Restart();    //1s?E�ga?E�CO�}?�E?e?�}?A           
        uart0_putc(s[--i], 0);
    }   while (i);  
}
//**********************************************************
//??UART2�fE?M?p?�e?R?t?��???n?o?I
//----------------------------------------------------------  
//  UART2?E?U�e�}?3?e??RS-485A�~Y?��ET(ADM3072E)�eO�fn?I�e??o?M?��?a?t?��
//----------------------------------------------------------
//  ?o?�h
//   % I�~�CT I�N��UAT?? ?I?�E?w�fe?��???n
//       |    |        |
//       |    |        + c: 1?��???o?I    s: ?��???n?o?I
//     |    + 0?`19    d: 10?i?�h???��?L u: 10?i?�h???��?3
//     |               X: 16?i?�h       b: 2?i?�h
//     + 0: 0?l?s      l: long?^�gu?I ex) %06ld
//----------------------------------------------------------  
//**********************************************************
void uart0_printf(int8_t *str, ...)
{
    va_list arp;
    int8_t d, r, w, s, l;
    int8_t *pt;

    DE_485 = 1; //ADM7032EAT�~2ETEnable(�e??MO��AT?w?O?e�eO?|)
    RE_485 = 1; //ADM7032EU?��ETDisable(�e??MO��AT?w?O?e�eO?|)
    //delay_ms(1);    //DE?c?c�e??M?J?n?U?A?I3a2A
            
    va_start(arp, str);

    while ((d = *str++) != 0) {
        R_Config_WDT_Restart();    //1s?E�ga?E�CO�}?�E?e?�}?A           
        if (d != '%') {
            uart0_putc(d ,0); continue;
        }
        d = *str++; w = r = s = l = 0;
        if (d == '0') {
            d = *str++; s = 1;
        }
        while ((d >= '0')&&(d <= '9')) {
            w += (int8_t)(w * 10 + (d - '0'));
            d = *str++;
        }
        if (s) w = (int8_t)(-w);
        if (d == 'l') {
            l = 1;
            d = *str++;
        }
        if (!d) break;
        if (d == 's') {
            pt = va_arg(arp, int8_t*);
            uart0_puts(pt, 0);
            continue;
        }
        if (d == 'c') {
            uart0_putc((char)va_arg(arp, short), 0);
            continue;
        }
        if (d == 'u') r = 10;
        if (d == 'd') r = -10;
        if (d == 'X') r = 16;
        if (d == 'o') r = 8;
        if (d == 'b') r = 2;
        if (!r) break;
        if (l) {
            uart0_itoa((long)va_arg(arp, long), r, w);
        } else {
            if (r > 0)
                uart0_itoa((unsigned long)va_arg(arp, unsigned short), r, w);
            else
                uart0_itoa((long)va_arg(arp, short), r, w);
        }
    }
    va_end(arp);
    
    DE_485 = 0; //ADM7032EAT�~2ETDisable(?o?MO��AT?w?O?e�eO?|)
    RE_485 = 0; //ADM7032EU?��ETEnable(?o?MO��AT?w?O?e�eO?|)
}
/* End user code. Do not edit comment generated here */
